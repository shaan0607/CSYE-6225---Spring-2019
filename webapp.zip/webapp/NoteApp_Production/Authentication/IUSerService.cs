namespace trial3.Authentication{
    public interface IUSerServices{
        
        Users Authenticate(string Email, string Password);

    }


}